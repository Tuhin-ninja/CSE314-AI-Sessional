#!/bin/bash

python3 task.py
python3 report.py